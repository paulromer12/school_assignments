<!DOCTYPE html>
<html lang="en">
<head>
    <title>Paul's First Program</title>
</head>
<body>
    <h1>CSD440 Module 1 Assignment</h1>
    <?php
    // PHP snipit to display text to the screen
    echo "This is a simple program for the first assignment of CSD440 as part of Module 1.";
    ?>
</body>
</html>